package Config;

public class Properties {
    public static boolean isDebug = false;
}
