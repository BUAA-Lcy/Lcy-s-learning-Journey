/**
 * @author Yangtze
 * @version 1.0
 * @date 2022/11/21 19:51
 */

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello Java!");
        test();
    }
    public static void test(){
        System.out.println("Hi");
    }
}
