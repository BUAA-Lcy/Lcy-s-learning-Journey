//author:Lcy
public class Lexical_unit {
    public int linenum;
    public String token;
    public String value;
    public Lexical_unit(int linenum, String token, String value) {
        this.linenum = linenum;
        this.token = token;
        this.value = value;
    }
}
