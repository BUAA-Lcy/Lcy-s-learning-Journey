package front;

import java.util.List;

public class FuncTable {
    public String name;
    //参数列表
    public List<Symbol> Parameters;
    public FuncTable(String name) {
        this.name = name;
    }
    public FuncTable(String name, List<Symbol> Params) {
        this.name = name;
        this.Parameters = Params;
    }
}
