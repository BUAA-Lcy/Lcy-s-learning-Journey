package ir.types;

/**
 * ArrayType
 * FunctionType
 * IntegerType
 * LabelType
 * PointerType
 * VoidType
 */
public interface Type {
}
